#!/usr/bin/env python3
"""Integra cuatro fotografías de Lu Roth en el HTML de Casa de Lux, sin modificar otras escenas.
Uso: python integrar_4_planos.py /ruta/al/index.html
"""
from pathlib import Path
import sys, json
if len(sys.argv)!=2:
    raise SystemExit('Uso: python integrar_4_planos.py /ruta/al/index.html')
html=Path(sys.argv[1])
if not html.is_file():
    raise SystemExit('No existe: '+str(html))
text=html.read_text(encoding='utf-8')
rows=json.loads((Path(__file__).parent/'nuevos_planos.json').read_text(encoding='utf-8'))
marker='\n];\n// El orden debe ser fijo para que el número del catálogo siempre corresponda al plano real.'
start=text.find('const nuevosPlanos=[')
if start<0:
    raise SystemExit('No se encuentra el catálogo de planos')
end=text.find(marker,start)
if end<0:
    raise SystemExit('No se encuentra el cierre del catálogo')
added=[r for r in rows if r['src'] not in text[start:end]]
if not added:
    print('Los cuatro planos ya están referenciados')
    raise SystemExit(0)
items=[]
for r in added:
    def quote(x): return json.dumps(x,ensure_ascii=False)
    items.append(' {name:'+quote(r['name'])+',group:'+quote(r['group'])+',time:'+quote(r['time'])+',src:'+quote(r['src'])+'}')
segment=text[start:end].rstrip()
if not segment.rstrip().endswith(','):
    segment+=','
segment+='\n'+',\n'.join(items)
text=text[:start]+segment+text[end:]
html.write_text(text,encoding='utf8')
print('Integrados:',len(added),'planos en',html)
